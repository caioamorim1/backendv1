export interface CreateGrupoDTO {
  nome: string;
  redeId?: string;
}

export interface AtualizarGrupoDTO {
  nome?: string;
  redeId?: string;
}
